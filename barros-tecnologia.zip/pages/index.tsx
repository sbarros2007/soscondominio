import { useState } from "react";
import { ShoppingCart } from "lucide-react";

const produtos = [
  { nome: "Câmera Full HD", descricao: "Alta definição, visão noturna e acesso remoto.", preco: 299.99 },
  { nome: "Alarme Inteligente", descricao: "Sensores modernos com notificação no celular.", preco: 199.99 },
  { nome: "Kit de Ferramentas", descricao: "Completo para instalações e manutenções.", preco: 149.99 },
  { nome: "Fios e Cabos", descricao: "Alta qualidade para instalações elétricas.", preco: 89.90 },
  { nome: "Fechadura Digital", descricao: "Controle de acesso com senha e biometria.", preco: 379.00 },
  { nome: "Central de Automação", descricao: "Controle todos os dispositivos da casa em um só lugar.", preco: 449.99 },
];

export default function HomePage() {
  const [carrinho, setCarrinho] = useState([]);

  const adicionarAoCarrinho = (produto) => {
    setCarrinho([...carrinho, produto]);
  };

  const valorTotal = carrinho.reduce((total, item) => total + item.preco, 0);

  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-black text-white p-4 shadow-md flex justify-between items-center">
        <h1 className="text-2xl font-bold">Barros Tecnologia e Automação</h1>
        <button className="text-white border border-white rounded px-4 py-2 flex items-center">
          <ShoppingCart className="mr-2" /> Carrinho ({carrinho.length})
        </button>
      </header>

      <main className="p-6">
        {/* BANNERS DESTAQUE */}
        <section className="mb-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-[url('/banners/cameras.jpg')] bg-cover bg-center rounded-xl p-8 text-white shadow-md">
              <h2 className="text-3xl font-bold mb-2">Segurança em Alta Definição</h2>
              <p>Câmeras modernas com acesso remoto e visão noturna.</p>
            </div>
            <div className="bg-[url('/banners/automacao.jpg')] bg-cover bg-center rounded-xl p-8 text-white shadow-md">
              <h2 className="text-3xl font-bold mb-2">Automação Residencial</h2>
              <p>Controle sua casa com tecnologia de ponta.</p>
            </div>
          </div>
        </section>

        <section className="text-center mb-10">
          <h2 className="text-3xl font-semibold mb-2">Soluções em Segurança Eletrônica</h2>
          <p className="text-gray-600">Câmeras, alarmes, ferramentas, materiais elétricos e muito mais.</p>
        </section>

        <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {produtos.map((produto) => (
            <div key={produto.nome} className="hover:shadow-lg transition-shadow border rounded p-4">
              <h3 className="text-xl font-medium mb-2">{produto.nome}</h3>
              <p className="text-sm text-gray-600 mb-2">{produto.descricao}</p>
              <p className="text-lg font-semibold mb-4">R$ {produto.preco.toFixed(2)}</p>
              <button className="w-full bg-black text-white px-4 py-2 rounded" onClick={() => adicionarAoCarrinho(produto)}>
                Adicionar ao Carrinho
              </button>
            </div>
          ))}
        </section>

        <section id="checkout" className="mt-16">
          <h2 className="text-2xl font-semibold mb-4">Resumo do Carrinho</h2>
          {carrinho.length === 0 ? (
            <p className="text-gray-600">Seu carrinho está vazio.</p>
          ) : (
            <div className="space-y-2">
              {carrinho.map((item, index) => (
                <div key={index} className="flex justify-between border-b pb-1">
                  <span>{item.nome}</span>
                  <span>R$ {item.preco.toFixed(2)}</span>
                </div>
              ))}
              <div className="flex justify-between font-semibold border-t pt-2">
                <span>Total</span>
                <span>R$ {valorTotal.toFixed(2)}</span>
              </div>
              <button className="mt-4 w-full bg-green-600 text-white px-4 py-2 rounded">Finalizar Compra</button>
            </div>
          )}
        </section>

        <section id="sobre" className="mt-16">
          <h2 className="text-2xl font-semibold mb-4">Sobre Nós</h2>
          <p className="text-gray-700 leading-relaxed">
            A Barros Tecnologia e Automação é especializada em soluções de segurança eletrônica, automação residencial e infraestrutura elétrica.
          </p>
        </section>

        <section id="contato" className="mt-16">
          <h2 className="text-2xl font-semibold mb-4">Fale Conosco</h2>
          <form className="grid grid-cols-1 gap-4 max-w-xl">
            <input className="border border-gray-300 rounded p-2" type="text" placeholder="Seu nome" />
            <input className="border border-gray-300 rounded p-2" type="email" placeholder="Seu e-mail" />
            <textarea className="border border-gray-300 rounded p-2" rows={4} placeholder="Sua mensagem"></textarea>
            <button className="w-full bg-black text-white px-4 py-2 rounded">Enviar</button>
          </form>
        </section>
      </main>

      <footer className="bg-gray-100 text-center p-4 mt-10 text-sm text-gray-500">
        © 2025 Barros Tecnologia e Automação. Todos os direitos reservados.
      </footer>
    </div>
  );
}
